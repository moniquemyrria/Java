/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Classes;
        
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

/**
 *
 * @author MONIQUE ROCHA
 */
public class SerializarRegistros implements Serializable {
    
    //BACKLOG
    public void GravarDadosBacklog(BackLog backlog, String ID) {
        CaminhoArquivosSerializacao caminhoPasta = new CaminhoArquivosSerializacao();
        try {
            FileOutputStream caminhoArquivo = new FileOutputStream(caminhoPasta.caminhoArquivoPastaPrincipal() + "Backlog\\" + ID + ".txt");
            ObjectOutputStream dadosObjeto = new ObjectOutputStream(caminhoArquivo);
            dadosObjeto.writeObject(backlog);
            dadosObjeto.close();
            caminhoArquivo.close();
        } catch (Exception exp) {
            exp.printStackTrace();
        }
    }
    
    //USUARIO
    public void GravarDadosUsuario(Usuario usuario, String ID) {
        CaminhoArquivosSerializacao caminhoPasta = new CaminhoArquivosSerializacao();
        try {
            FileOutputStream caminhoArquivo = new FileOutputStream(caminhoPasta.caminhoArquivoPastaPrincipal() + "Usuario\\" + ID + ".txt");
            ObjectOutputStream dadosObjeto = new ObjectOutputStream(caminhoArquivo);
            dadosObjeto.writeObject(usuario);
            dadosObjeto.close();
            caminhoArquivo.close();
        } catch (Exception exp) {
            exp.printStackTrace();
        }
    }
    
    //PROGRAMADOR
    public void GravarDadosProgramador(Programador programador, String ID) {
        CaminhoArquivosSerializacao caminhoPasta = new CaminhoArquivosSerializacao();
        try {
            FileOutputStream caminhoArquivo = new FileOutputStream(caminhoPasta.caminhoArquivoPastaPrincipal() + "Programador\\" + ID + ".txt");
            ObjectOutputStream dadosObjeto = new ObjectOutputStream(caminhoArquivo);
            dadosObjeto.writeObject(programador);
            dadosObjeto.close();
            caminhoArquivo.close();
        } catch (Exception exp) {
            exp.printStackTrace();
        }
    }
    
    //PROJETO
    public void GravarDadosProjeto(Projeto projeto, String ID) {
        CaminhoArquivosSerializacao caminhoPasta = new CaminhoArquivosSerializacao();
        try {
            FileOutputStream caminhoArquivo = new FileOutputStream(caminhoPasta.caminhoArquivoPastaPrincipal() + "Projeto\\" + ID + ".txt");
            ObjectOutputStream dadosObjeto = new ObjectOutputStream(caminhoArquivo);
            dadosObjeto.writeObject(projeto);
            dadosObjeto.close();
            caminhoArquivo.close();
        } catch (Exception exp) {
            exp.printStackTrace();
        }
    }
    
    //SPRINT
    public void GravarDadosSprint(Sprint sprint, String ID) {
        CaminhoArquivosSerializacao caminhoPasta = new CaminhoArquivosSerializacao();
        try {
            FileOutputStream caminhoArquivo = new FileOutputStream(caminhoPasta.caminhoArquivoPastaPrincipal() + "Sprint\\" + ID + ".txt");
            ObjectOutputStream dadosObjeto = new ObjectOutputStream(caminhoArquivo);
            dadosObjeto.writeObject(sprint);
            dadosObjeto.close();
            caminhoArquivo.close();
        } catch (Exception exp) {
            exp.printStackTrace();
        }
    }
    
    //TIPO ATIVIDADE
    public void GravarDadosTipoAtividade(TipoAtividade tipoAtividade, String ID) {
        CaminhoArquivosSerializacao caminhoPasta = new CaminhoArquivosSerializacao();
        try {
            FileOutputStream caminhoArquivo = new FileOutputStream(caminhoPasta.caminhoArquivoPastaPrincipal() + "TipoAtividade\\" + ID + ".txt");
            ObjectOutputStream dadosObjeto = new ObjectOutputStream(caminhoArquivo);
            dadosObjeto.writeObject(tipoAtividade);
            dadosObjeto.close();
            caminhoArquivo.close();
        } catch (Exception exp) {
            exp.printStackTrace();
        }
    }
}
