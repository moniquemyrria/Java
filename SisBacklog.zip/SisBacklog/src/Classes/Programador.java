
package Classes;

import java.io.Serializable;

public class Programador implements Serializable{
    private int ID;
    private String nome;
    
    public Programador (){
        
        
    }

    /**
     * @return the id
     */
    public int getId() {
        return ID;
    }

    /**
     * @param id the id to set
     */
    public void setID(int ID) {
        this.ID = ID;
    }

    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }
}
