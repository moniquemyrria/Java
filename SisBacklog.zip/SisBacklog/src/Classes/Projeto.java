/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Classes;

import java.io.Serializable;

/**
 *
 * @author Igor
 */
public class Projeto implements Serializable{
    //visibilidade - Tipo - Dado
    private int id;
    private String nome;
    //construtor projeto
    
    public Projeto(){
   
    }

    /**
     * @return the ID
     */
    public int getId() {
        return id;
    }

    /**
     * @param ID the ID to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }
}
