/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Classes;
        
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.io.Serializable;

/**
 *
 * @author MONIQUE ROCHA
 */
public class DeserializarRegistros implements Serializable{
    
    //BACKLOG
    public BackLog LerDadosBacklog(String ID) {
        BackLog backlog = null;
        try {
            CaminhoArquivosSerializacao caminhoPasta = new CaminhoArquivosSerializacao();
            FileInputStream caminhoArquivo = new FileInputStream(caminhoPasta.caminhoArquivoPastaPrincipal() + "Backlog\\"  + ID + ".txt");
            ObjectInputStream dadosObjeto = new ObjectInputStream(caminhoArquivo);
            backlog = (BackLog) dadosObjeto.readObject();
            dadosObjeto.close();
            caminhoArquivo.close();
            //return backlog;
        } catch (Exception exp) {
        }
        return backlog;
    }
    
    //USUARIO
    public Usuario LerDadosUsuario(String ID) {
        Usuario usuario = null; 
        try {
            CaminhoArquivosSerializacao caminhoPasta = new CaminhoArquivosSerializacao();
            FileInputStream caminhoArquivo = new FileInputStream(caminhoPasta.caminhoArquivoPastaPrincipal() + "Usuario\\" + ID + ".txt");
            ObjectInputStream dadosObjeto = new ObjectInputStream(caminhoArquivo);
            usuario = (Usuario) dadosObjeto.readObject();
            dadosObjeto.close();
            caminhoArquivo.close();
        } catch (Exception exp) {
        }
        return usuario;
    }
    
    //PROGRAMADOR
    public Programador LerDadosProgramador(String ID) {
        Programador programador = null;
        try {
            CaminhoArquivosSerializacao caminhoPasta = new CaminhoArquivosSerializacao();
            FileInputStream caminhoArquivo = new FileInputStream(caminhoPasta.caminhoArquivoPastaPrincipal() + "Programador\\" + ID + ".txt");
            ObjectInputStream dadosObjeto = new ObjectInputStream(caminhoArquivo);
            programador = (Programador) dadosObjeto.readObject();
            dadosObjeto.close();
            caminhoArquivo.close();
        } catch (Exception exp) {
        }
        return programador;
    }
    
    //PROJETO
    public Projeto LerDadosProjeto(String ID) {
        Projeto projeto = null; 
        try {
            CaminhoArquivosSerializacao caminhoPasta = new CaminhoArquivosSerializacao();
            FileInputStream caminhoArquivo = new FileInputStream(caminhoPasta.caminhoArquivoPastaPrincipal() + "Projeto\\" + ID + ".txt");
            ObjectInputStream dadosObjeto = new ObjectInputStream(caminhoArquivo);
            projeto = (Projeto) dadosObjeto.readObject();
            dadosObjeto.close();
            caminhoArquivo.close();
        } catch (Exception exp) {
        }
        return projeto;
    }
    
    //SPRINT
    public Sprint LerDadosSprint(String ID) {
        Sprint sprint = null;
        try {
            CaminhoArquivosSerializacao caminhoPasta = new CaminhoArquivosSerializacao();
            FileInputStream caminhoArquivo = new FileInputStream(caminhoPasta.caminhoArquivoPastaPrincipal() + "Sprint\\" + ID + ".txt");
            ObjectInputStream dadosObjeto = new ObjectInputStream(caminhoArquivo);
            sprint = (Sprint) dadosObjeto.readObject();
            dadosObjeto.close();
            caminhoArquivo.close();
        } catch (Exception exp) {
        }
        return sprint;
    }
    
    //TIPO ATIVIDADE
    public TipoAtividade LerDadosTipoAtividade(String ID) {
        TipoAtividade tipoAtividade = null;
        try {
            CaminhoArquivosSerializacao caminhoPasta = new CaminhoArquivosSerializacao();
            FileInputStream caminhoArquivo = new FileInputStream(caminhoPasta.caminhoArquivoPastaPrincipal() + "TipoAtividade\\" + ID + ".txt");
            ObjectInputStream dadosObjeto = new ObjectInputStream(caminhoArquivo);
            tipoAtividade = (TipoAtividade) dadosObjeto.readObject();
            dadosObjeto.close();
            caminhoArquivo.close();
        } catch (Exception exp) {
        }
        return tipoAtividade; 
    }
    
}
