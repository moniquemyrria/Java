package Classes;

import java.io.Serializable;

/**
*
* @author Ricardo
*/

public class Usuario implements Serializable{
    private int ID;
    private String login;
    private String senha;
    private String tipoAcesso;
  
    public Usuario(){
    
    }
    public int getId() {
        return ID;
    }

    public void setId(int id) {
        this.ID = id;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public String getTipoAcesso() {
        return tipoAcesso;
    }

    public void setTipoAcesso(String tipoacesso) {
        this.tipoAcesso = tipoacesso;
    }
    
}

//adicionar - CADASTRAR PESQUISAR ALTERAR, EXCLUIR, REALIZAR LOGIN, criar um novo Controller?