/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Classes;

import java.io.Serializable;

/**
 *
 * @author Gabees e Monique
 */
public class BackLog implements Serializable{
    
    private int ID;
    private String descricaoAtividade;
    private String prioridade;
    private String status;
   
    private Projeto projeto;
    private TipoAtividade tipoAtividade;
    private Programador programador;
    private Sprint sprint;
    
    //Construtor classe Backlog
    public BackLog(){
        //Delegação
        //Instanciando Projeto e Tipo de atividade, programador e sprint
        tipoAtividade =  new TipoAtividade();
        projeto = new Projeto();
        programador = new Programador();
        sprint = new Sprint();
    }

    /**
     * @return the ID
     */
    public int getID() {
        return ID;
    }

    /**
     * @param ID the ID to set
     */
    public void setID(int ID) {
        this.ID = ID;
    }

    /**
     * @return the descricaoAtividade
     */
    public String getDescricaoAtividade() {
        return descricaoAtividade;
    }

    /**
     * @param descricaoAtividade the descricaoAtividade to set
     */
    public void setDescricaoAtividade(String descricaoAtividade) {
        this.descricaoAtividade = descricaoAtividade;
    }

    /**
     * @return the prioridade
     */
    public String getPrioridade() {
        return prioridade;
    }

    /**
     * @param prioridade the prioridade to set
     */
    public void setPrioridade(String prioridade) {
        this.prioridade = prioridade;
    }

    /**
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(String status) {
        this.status = status;
    }
    
     //DELEGANDO Get e Set - CLASSE PROJETO
    public String getNomeProjeto(){
        return this.projeto.getNome();
    }
    
     public void setNomeProjeto(String descProjeto){
        projeto.setNome(descProjeto);
    }
     
     //DELEGANDO Get e Set - CLASSE TIPO DE ATIVIDADE
    public String getTipoAtividade(){
        return this.tipoAtividade.getDescricao();
    }
    
     public void setTipoAtividade(String descTipoAtividade){
        tipoAtividade.setDescricao(descTipoAtividade);
    }
     
     //DELEGANDO Get e Set - CLASSE PROGRAMADOR
    public String getNomeProgramador(){
        return this.programador.getNome();
    }
    
     public void setNomeProgramador(String nomeProgramador){
        programador.setNome(nomeProgramador);
    }
     
    //DELEGANDO Get e Set - CLASSE SPRINT
    public String getSpSprint(){
        return this.sprint.getSp();
    }
    
     public void setSpSprint(String spSprint){
        sprint.setSp(spSprint);
    }
     
    public String getDataFinalEntrega(){
        return this.sprint.getDataFinal();
    }
    
     public void setDataFinalEntrega(String dataFinalEntrega){
        sprint.setDataFinal(dataFinalEntrega);
    }
}
