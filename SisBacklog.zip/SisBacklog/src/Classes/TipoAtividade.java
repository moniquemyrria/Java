/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Classes;

import java.io.Serializable;

/**
 *
 * @author karla
 */
public class TipoAtividade implements Serializable{
    private int ID;
    private String descricao;
    
    public TipoAtividade(){
    }

    /**
     * @return the ID
     */
    public int getID() {
        return ID;
    }

    /**
     * @param ID the ID to set
     */
    public void setID(int ID) {
        this.ID = ID;
    }

    /**
     * @return the DescriçãoAtividade
     */
    public String getDescricao() {
        return descricao;
    }

    /**
     * @param Descricao the DescriçãoAtividade to set
     */
    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }
}