
package sisbacklog;
import View.ViewLogin;
import View.ViewMenuPrincipal;

public class SisBacklog {


    public static void main(String[] args) {

        ViewLogin telaLogin = new ViewLogin();
        telaLogin.setVisible(true);
    }
    
}
